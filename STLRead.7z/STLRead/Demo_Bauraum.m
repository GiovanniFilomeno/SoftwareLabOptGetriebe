Bauraum = stlread('Bauraum.stl');
fv = stlread('Gearbox1.stl');