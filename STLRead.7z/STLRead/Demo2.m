clear all
clc

BR=stlread("Bauraum.STL");
V = BR.Points;
V2 = 0.004.*V;
F = BR.ConnectivityList;
N = faceNormal(BR);

bauraum = struct('faces',F,'vertices',V2);

xmax = max(V2(:,1))
xmin = min(V2(:,1))
ymax = max(V2(:,2))
ymin = min(V2(:,2))
zmax = max(V2(:,3))
zmin = min(V2(:,3))

x = xmin + (xmax-xmin).*rand(10,1);
y = ymin + (ymax-ymin).*rand(10,1);
z = zmin + (zmax-zmin).*rand(10,1);

coords = [x,y,z]
