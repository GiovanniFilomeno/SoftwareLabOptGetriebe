function VisualizeMany(n, iter,bauraum, gearbox,Anchor, EC1,EC1_width, EC1_center, EC1_SurfCenter, EC2, EC2_center, EC2_SurfCenter, EC3, EC3_center, EC3_SurfCenter, EC4, EC4_center, EC4_SurfCenter, EM_start,EM_vector, Fitness,r,y,theta,Rotations,EC2_placement)


for i = 1:n
    
    VisualizeLast(i,n, iter,bauraum, gearbox,Anchor, EC1,EC1_width, EC1_center, EC1_SurfCenter, EC2, EC2_center, EC2_SurfCenter, EC3, EC3_center, EC3_SurfCenter, EC4, EC4_center, EC4_SurfCenter, EM_start,EM_vector, Fitness,r,y,theta,Rotations,EC2_placement)
    
end

end