clear all
clc
tStart = cputime;

%% Loading all the solids
%Read Gearbox
FV=stlread("Gearbox1.STL");
V = FV.Points;
V1 = 1000.*V;
F = FV.ConnectivityList;
N = faceNormal(FV);
fv = struct('faces',F,'vertices',V1);

%Read Assembly space
BR=stlread("Bauraum.STL");
V = BR.Points;
F = BR.ConnectivityList;
N = faceNormal(BR);
bauraum = struct('faces',F,'vertices',V);

% Defining the limits of the bauraum to generate the population inside.
xmax = max(bauraum.vertices(:,1));
xmin = min(bauraum.vertices(:,1));
ymax = max(bauraum.vertices(:,2));
ymin = min(bauraum.vertices(:,2));
zmax = max(bauraum.vertices(:,3));
zmin = min(bauraum.vertices(:,3));

%Read 4 Electric components and set Right dimensions
Cube=stlread("cube.STL");
V = Cube.Points;

V2(:,2) = 0.566.*V(:,1);
V2(:,1) = 0.2045.*V(:,2);
V2(:,3) = 0.07629.*V(:,3);

V3(:,2) = 1.12736.*V(:,1);
V3(:,1) = 0.24335.*V(:,2);
V3(:,3) = 0.12534.*V(:,3);

V4(:,2) = 0.3302.*V(:,1);
V4(:,1) = 0.06135.*V(:,2);
V4(:,3) = 0.06812.*V(:,3);

V5(:,2) = 1.4151.*V(:,1);
V5(:,1) = 0.3681.*V(:,2);
V5(:,3) = 0.0545.*V(:,3);

F = Cube.ConnectivityList;
N = faceNormal(Cube);

%IGBT
EC1 = struct('faces',F,'vertices',V2);

%DC-Link Capacitor
EC2 = struct('faces',F,'vertices',V3);

%EMI-Filter
EC3 = struct('faces',F,'vertices',V4);

%Control board
EC4 = struct('faces',F,'vertices',V5);


bauraum_mov = [xmin ymin zmin];
bauraum.vertices = bauraum.vertices - bauraum_mov;

%Plot Bauraum
BRaum = patch(bauraum,'FaceColor',       [0 0 1.0], ...
         'EdgeColor',       'none',        ...
         'FaceLighting',    'gouraud',     ...
         'AmbientStrength', 0.15);
BRaum.FaceVertexAlphaData = 0.2;    % Set constant transparency 
BRaum.FaceAlpha = 'flat' ;          % Interpolate to find face transparency
hold on
view([45 90 135]);
xlabel('X') 
ylabel('Y')
zlabel('Z')
%axis([0 10 0 10 0 10])
camlight('headlight');
material('default');

%% Positioning(manually) of the gearbox inside the bauraum
[EM_start, EM_vector, Anchor, EM_radius] = FindingAxis("Gearbox1.stl");
EM_end = EM_start + EM_vector;
zero = [0 0 0];

%Definition(manually of the axis of the bauraum shaft 
point = [2539 14 -40] - bauraum_mov;
vector = [0 -1 0];

%setting rotation angle values
if (EM_vector(1) ~= 0)
    if (EM_vector(1) > 0)
        anglex = 0;
        angley = 0;
        anglez = pi/2;
    else
        anglex = 0;
        angley = 0;
        anglez = -pi/2;
    end
end
    
if (EM_vector(2) ~= 0)
    if (EM_vector(2) > 0)
        anglex = 0;
        angley = 0;
        anglez = 0;
    else
        anglex = 0;
        angley = 0;
        anglez = 0;
    end
end
        
if (EM_vector(3) ~= 0)
    if (EM_vector(3) > 0)
        anglex = 0;
        angley = pi/2;
        anglez = -pi/2;
    else
        anglex = 0;
        angley = -pi/2;
        anglez = pi/2;
    end
end

%Positioning of the gearbox inside the Bauraum
fv.vertices = fv.vertices - Anchor + point;
EM_start = EM_start - Anchor + point;
Anchor = point;
shaftx = [point(1) point(1)];
shafty = [point(2) point(2) - 119];
shaftz = [point(3) point(3)];
plot3(shaftx', shafty', shaftz','LineWidth',2,'Color','red')
hold on
pause(1)
fv.vertices = rotation(fv.vertices,Anchor, 1, anglex);
fv.vertices = rotation(fv.vertices,Anchor, 2, angley);
fv.vertices = rotation(fv.vertices,Anchor, 3, anglez);
EM_start = rotation(EM_start, Anchor, 1, anglex);
EM_start = rotation(EM_start, Anchor, 2, angley);
EM_start = rotation(EM_start, Anchor, 3, anglez);
EM_vector = rotation(EM_vector, zero, 1, anglex);
EM_vector = rotation(EM_vector, zero, 2, angley);
EM_vector = rotation(EM_vector, zero, 3, anglez);
EM_end = EM_start + EM_vector;

%Obtaining the angle range for the gearbox to rotate without escaping the
%bauraum
out_gearbox = [];
for i= 1:360
    
    fv.vertices = rotation(fv.vertices,Anchor, 2, pi/180);
    EM_start = rotation(EM_start, Anchor, 2, pi/180);
    EM_vector = rotation(EM_vector, zero, 2, pi/180);
    EM_end = EM_start + EM_vector;
    EM_shaftx = [EM_start(1,1) EM_start(1,1) + EM_vector(1,1)];
    EM_shafty = [EM_start(1,2) EM_start(1,2) + EM_vector(1,2)];
    EM_shaftz = [EM_start(1,3) EM_start(1,3) + EM_vector(1,3)];
    
    IN = inpolyhedron(bauraum,fv.vertices);
    out_gearbox(i) = sum(IN)/length(IN); 
end

valid_angles = [];
max_IN = max(out_gearbox)


for i= 1:360
    if (out_gearbox(i) == max_IN)
        valid_angles(end+1) = i;
        valid_radians = valid_angles.*(pi/180);
    end
end
out_gearbox = [];
angle_range = valid_angles(length(valid_angles)) - valid_angles(1);
rad_range = (length(valid_angles))*pi/180;

if angle_range == length(valid_angles) - 1
    first_angle = valid_radians(1);
else
    for i=1:length(valid_radians)
        if i==1
            valid_diff(i) = valid_radians(1) - valid_radians(length(valid_radians)); 
        else
            valid_diff(i) = valid_radians(i) - valid_radians(i-1);
        end
    end
    [srt,I] = sort(valid_diff, 'descend');
    first_angle = valid_radians(I(1,1));
end

fv.vertices = rotation(fv.vertices,Anchor, 2, first_angle);
EM_start = rotation(EM_start, Anchor, 2, first_angle);
EM_end = EM_start + EM_vector;

%% Defining the limits of the bauraum to generate the population inside.
xmax = max(bauraum.vertices(:,1));
xmin = min(bauraum.vertices(:,1));
ymax = max(bauraum.vertices(:,2));
ymin = min(bauraum.vertices(:,2));
zmax = max(bauraum.vertices(:,3));
zmin = min(bauraum.vertices(:,3));


%% Defining the limits and centers of the Electric components

%IGBT
EC1_xmax = max(EC1.vertices(:,1));
EC1_xmin = min(EC1.vertices(:,1));
EC1_ymax = max(EC1.vertices(:,2));
EC1_ymin = min(EC1.vertices(:,2));
EC1_zmax = max(EC1.vertices(:,3));
EC1_zmin = min(EC1.vertices(:,3));
EC1_length = abs(EC1_xmax - EC1_xmin);
EC1_width = abs(EC1_ymax - EC1_ymin);
EC1_height = abs(EC1_zmax - EC1_zmin);
EC1_center = [(EC1_xmax + EC1_xmin)/2 (EC1_ymax + EC1_ymin)/2 (EC1_zmax + EC1_zmin)/2]; 

EC1_center1 = [EC1_xmax (EC1_ymax + EC1_ymin)/2 (EC1_zmax + EC1_zmin)/2]; %Counterclockwise

EC1_center2 = [EC1_xmin (EC1_ymax + EC1_ymin)/2 (EC1_zmax + EC1_zmin)/2]; %Clockwise

%To use with Control board
EC1_center3 = [(EC1_xmax + EC1_xmin)/2 (EC1_ymax + EC1_ymin)/2 EC1_zmax];  


%Capacitor
EC2_xmax = max(EC2.vertices(:,1));
EC2_xmin = min(EC2.vertices(:,1));
EC2_ymax = max(EC2.vertices(:,2));
EC2_ymin = min(EC2.vertices(:,2));
EC2_zmax = max(EC2.vertices(:,3));
EC2_zmin = min(EC2.vertices(:,3));
EC2_length = abs(EC2_xmax - EC2_xmin);
EC2_width = abs(EC2_ymax - EC2_ymin);
EC2_height = abs(EC2_zmax - EC2_zmin);
EC2_center = [(EC2_xmax + EC2_xmin)/2 (EC2_ymax + EC2_ymin)/2  (EC2_zmax + EC2_zmin)/2];

EC2_center1 = [EC2_xmax (EC2_ymax + EC2_ymin)/2  (EC2_zmax + EC2_zmin)/2]; 

EC2_center2 = [EC2_xmin (EC2_ymax + EC2_ymin)/2 (EC2_zmax + EC2_zmin)/2];


%EMI-filter
EC3_xmax = max(EC3.vertices(:,1));
EC3_xmin = min(EC3.vertices(:,1));
EC3_ymax = max(EC3.vertices(:,2));
EC3_ymin = min(EC3.vertices(:,2));
EC3_zmax = max(EC3.vertices(:,3));
EC3_zmin = min(EC3.vertices(:,3));
EC3_length = abs(EC3_xmax - EC3_xmin);
EC3_width = abs(EC3_ymax - EC3_ymin);
EC3_height = abs(EC3_zmax - EC3_zmin);
EC3_center = [(EC3_xmax + EC3_xmin)/2 (EC3_ymax + EC3_ymin)/2 (EC3_zmax + EC3_zmin)/2];

%To use with Condensator
EC3_center1 = [EC3_xmax (EC3_ymax + EC3_xmin)/2 (EC3_zmax + EC3_zmin)/2]; 

%Control board
EC4_xmax = max(EC4.vertices(:,1));
EC4_xmin = min(EC4.vertices(:,1));
EC4_ymax = max(EC4.vertices(:,2));
EC4_ymin = min(EC4.vertices(:,2));
EC4_zmax = max(EC4.vertices(:,3));
EC4_zmin = min(EC4.vertices(:,3));
EC4_length = abs(EC4_xmax - EC4_xmin);
EC4_width = abs(EC4_ymax - EC4_ymin);
EC4_height = abs(EC4_zmax - EC4_zmin);
EC4_center = [(EC4_xmax + EC4_xmin)/2 (EC4_ymax + EC4_ymin)/2 (EC4_zmax + EC4_zmin)/2]; 

%To use with IGBT
EC4_center1 = [(EC4_xmax + EC4_xmin)/2 (EC4_ymax + EC4_ymin)/2 EC4_zmin]; 
     
hold on     
patch(fv,'FaceColor',       [0.8 0.8 1], ...
     'FaceLighting',    'gouraud',     ...
     'AmbientStrength', 0.15);
plot3(shaftx', shafty', shaftz','LineWidth',2,'Color','red')
                 
%% Genetic Algorithm implementation
pop = 5;
iter = 5;


%Create first sample population and evaluate fitness
%Orientation of the gearbox
gb_rot = rad_range.*rand(pop,1);
gb_mov = zeros(pop,1);
for i=1:pop
    if i==1
        gb_mov(i) = gb_rot(i);
    else
        gb_mov(i) = gb_rot(i) - gb_rot(i-1);
    end
end

%IGBT
r1 = EM_radius + (EC1_height/2) + (EC1_height).*rand(pop,1);
y1= EM_start(2) + (EM_vector(2)).*rand(pop,1);
theta1 = -2*pi + 2*pi.*rand(pop,1);
coords1 = [EM_start(1)+ r1.*sin(theta1),y1,EM_start(3) + r1.*cos(theta1)];
% coords1 = [r1,y1,theta1];
EC1_rot = -pi/12 + (pi/6).*rand(pop,1);
theta1_mov = zeros(pop,1);
EC1_mov = zeros(pop,1);
for i=1:pop
    if i==1
        EC1_mov(i) = theta1(i) + EC1_rot(i);
    else
        EC1_mov(i) = theta1(i) + EC1_rot(i) - theta1(i-1) - EC1_rot(i-1);
    end
end


%Condensator
r2 = EM_radius + (EC2_height/2) + (EC2_height).*rand(pop,1);
y2= EM_start(2) + (EM_vector(2)).*rand(pop,1);
angle_range2 = (EC1_length + EC2_length)/(2*(EM_radius)); 
theta2_direction = rand(pop,1);
theta2 = zeros(pop,1);
for i=1:pop
    if theta2_direction(i) > 0.5
        theta2(i) = theta1(i) + angle_range2 + (pi/15)*rand();
    else
        theta2(i) = theta1(i) - angle_range2 - (pi/15)*rand();
    end
end   
coords2 = [EM_start(1)+ r2.*sin(theta2),y2,EM_start(3) + r2.*cos(theta2)];
EC2_rot = -pi/12 + (pi/6).*rand(pop,1);
EC2_mov = zeros(pop,1);
for i=1:pop
    if i==1
        EC2_mov(i) = theta2(i) + EC2_rot(i);
    else
        EC2_mov(i) = theta2(i) + EC2_rot(i) - theta2(i-1) - EC2_rot(i-1);
    end
end


%EMI-Filter
r3 = EM_radius + (EC3_height/2) + (EC3_height).*rand(pop,1);
y3= EM_start(2) + (EM_vector(2)).*rand(pop,1);
angle_range3 = (EC2_length + EC3_length)/(2*(EM_radius)); 
theta3 = zeros(pop,1);
for i=1:pop
    if theta2(i) > theta1(i)
        theta3(i) = theta2(i) + angle_range3 + (pi/15)*rand();
    else
        theta3(i) = theta2(i) - angle_range3 - (pi/15)*rand();
    end
end   
coords3 = [EM_start(1)+ r3.*sin(theta3),y3,EM_start(3) + r3.*cos(theta3)];
EC3_rot = -pi/12 + (pi/6).*rand(pop,1);
EC3_mov = zeros(pop,1);
for i=1:pop
    if i==1
        EC3_mov(i) = theta3(i) + EC3_rot(i);
    else
        EC3_mov(i) = theta3(i) + EC3_rot(i) - theta3(i-1) - EC3_rot(i-1);
    end
end



%Control board
r4 = r1 + (EC1_height/2) + (EC1_height).*rand(pop,1);
y1= EM_start(2) + (EM_vector(2)).*rand(pop,1);
theta4 = theta1;
coords4 = [EM_start(1)+ r4.*sin(theta4),y1,EM_start(3) + r4.*cos(theta4)];
% coords1 = [r1,y1,theta1];
EC4_rot = -pi/12 + (pi/6).*rand(pop,1);
theta4_mov = zeros(pop,1);
EC4_mov = zeros(pop,1);
for i=1:pop
    if i==1
        EC4_mov(i) = theta4(i) + EC4_rot(i);
    else
        EC4_mov(i) = theta4(i) + EC4_rot(i) - theta4(i-1) - EC4_rot(i-1);
    end
end


%Array that contain the fitness of the chromosome
d = zeros(pop,1);

for i=1:pop
    
    %Move the components and associated variables to the position of that chromosome
    %Gearbox
%     fv.vertices = rotation(fv.vertices, Anchor, 2, gb_mov(i,1));
%     EM_start = rotation(EM_start, Anchor, 2, gb_mov(i,1));
%     EM_end = EM_start + EM_vector;
    
    %IGBT
    EC1.vertices = EC1.vertices - EC1_center + coords1(i,:);
    EC1_center1 = EC1_center1 - EC1_center + coords1(i,:);
    EC1_center2 = EC1_center2 - EC1_center + coords1(i,:);
    EC1_center3 = EC1_center3 - EC1_center + coords1(i,:);
    EC1_center = coords1(i,:);
    EC1.vertices = rotation(EC1.vertices, EC1_center, 2, -EC1_mov(i,1));
    EC1_center1 = rotation(EC1_center1, EC1_center, 2, -EC1_mov(i,1));
    EC1_center2 = rotation(EC1_center2, EC1_center, 2, -EC1_mov(i,1));
    EC1_center3 = rotation(EC1_center3, EC1_center, 2, -EC1_mov(i,1));
    
    EC2.vertices = EC2.vertices - EC2_center + coords2(i,:);
    EC2_center1 = EC2_center1 - EC2_center + coords2(i,:);
    EC2_center2 = EC2_center2 - EC2_center + coords2(i,:);
    EC2_center = coords2(i,:);
    EC2.vertices = rotation(EC2.vertices, EC2_center, 2, -EC2_mov(i,1));
    EC2_center1 = rotation(EC2_center1, EC2_center, 2, -EC2_mov(i,1));
    EC2_center2 = rotation(EC2_center2, EC2_center, 2, -EC2_mov(i,1));
    
    EC3.vertices = EC3.vertices - EC3_center + coords3(i,:);
    EC3_center1 = EC3_center1 - EC3_center + coords3(i,:);
    EC3_center = coords3(i,:);
    EC3.vertices = rotation(EC3.vertices, EC3_center, 2, -EC3_mov(i,1));
    EC3_center1 = rotation(EC3_center1, EC3_center, 2, -EC3_mov(i,1));
    
    EC4.vertices = EC4.vertices - EC4_center + coords4(i,:);
    EC4_center1 = EC4_center1 - EC4_center + coords4(i,:);
    EC4_center = coords4(i,:);
    EC4.vertices = rotation(EC4.vertices, EC4_center, 2, -EC4_mov(i,1));
    EC4_center1 = rotation(EC4_center1, EC4_center, 2, -EC4_mov(i,1));
    
    patch(EC1,'FaceColor',       [0.8 0 0], ...
         'EdgeColor',       'green',        ...
         'FaceLighting',    'gouraud',     ...
         'AmbientStrength', 0.15);
     
     patch(EC2,'FaceColor',       [0 0.8 0], ...
         'EdgeColor',       'red',        ...
         'FaceLighting',    'gouraud',     ...
         'AmbientStrength', 0.15);
     
     patch(EC3,'FaceColor',       [1 1 0], ...
         'EdgeColor',       'black',        ...
         'FaceLighting',    'gouraud',     ...
         'AmbientStrength', 0.15);
     
     patch(EC4,'FaceColor',       [1 0 1], ...
         'EdgeColor',       'yellow',        ...
         'FaceLighting',    'gouraud',     ...
         'AmbientStrength', 0.15);
%      
    pause(0.1)
end


function vertex = rotation(V, anchor,indice, angle)

    Rz = [ cos(angle), -sin(angle), 0 ;
          sin(angle), cos(angle), 0 ;
    0, 0, 1 ];

    Ry = [ cos(angle), 0, sin(angle) ;
    0, 1, 0 ;
          -sin(angle), 0, cos(angle) ];
      
    Rx = [ 1, 0, 0 ;
    0, cos(angle), -sin(angle);
    0, sin(angle), cos(angle) ];

    if(indice==1)
           vertex = (V-anchor)*Rx + anchor;
    end
    if(indice==2)
           vertex = (V-anchor)*Ry + anchor;
    end
    if(indice==3)
           vertex = (V-anchor)*Rz + anchor;
    end

end 


